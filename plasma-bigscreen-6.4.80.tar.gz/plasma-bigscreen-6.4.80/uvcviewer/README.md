<!--
- SPDX-FileCopyrightText: None
- SPDX-License-Identifier: CC0-1.0
-->

# Bigscreen UVC Viewer
A simple viewer for UVC devices, such as an HDMI capture card, for Plasma Bigscreen.

Allows you to easily connect external devices, such as set top box or console (via a USB Capture device), to Bigscreen and view them on the TV.