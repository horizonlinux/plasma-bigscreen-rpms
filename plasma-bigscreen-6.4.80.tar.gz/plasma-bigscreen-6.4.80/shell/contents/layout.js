/*
    SPDX-FileCopyrightText: 2020 Marco Martin <mart@kde.org>
    SPDX-FileCopyrightText: 2025 Seshan Ravikumar <seshan@sineware.ca>
    SPDX-License-Identifier: LGPL-2.0-or-later
*/

// See lookandfeel/contents/layouts/org.kde.plasma.bigscreen-layout.js for the layout.