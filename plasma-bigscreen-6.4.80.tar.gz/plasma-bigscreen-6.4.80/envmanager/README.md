<!--
- SPDX-FileCopyrightText: None
- SPDX-License-Identifier: CC0-1.0
-->

# Bigscreen Envmanager
(based on https://invent.kde.org/plasma/plasma-mobile/-/tree/master/envmanager)